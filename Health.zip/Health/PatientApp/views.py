from django.shortcuts import render
def FacultyHomePage(request):
    return render(request, 'PatientApp/PatientHomePage.html')