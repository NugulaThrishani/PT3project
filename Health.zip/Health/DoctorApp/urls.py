from django.urls import path, include
from .import views
from django.urls import path
urlpatterns=[
    path('', views.ProjectHomePage, name='ProjectHomePage'),

    path('add_task/',views.add_task, name='add_task'),
    path('<int:pk>/delete/', views.delete_task, name='delete_task'),
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),

    path('UserLoginPageCall/', views.UserLoginPageCall, name='UserLoginPageCall'),
    path('UserLoginLogic/', views.UserLoginLogic, name='UserLoginLogic'),
    path('UserSignUpPageCall/', views.UserSignUpPageCall, name='UserSignUpPageCall'),
    path('UserSignUpLogic/', views.UserSignUpLogic, name='UserSignUpLogic'),
    path('add_student/', views.add_student, name='add_student'),
    #path('PatientApp/',include('PatientApp.urls',namespace='PatientApp')),
    #path('MedicineApp/',include('MedicineApp.urls',namespace='MedicineApp')),

]