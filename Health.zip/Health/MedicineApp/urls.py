from django.urls import path, include
from . import views
app_name='MedicineApp'

urlpatterns = [
    path('StudentHomePage/',views.StudentHomePage,name='StudentHomePage'),
]