from django.shortcuts import render



# Create your views here.
def ProjectHomePage(request):
    return render(request,'AdminApp/ProjectHomePage.html')

def PatientHomePage(request):
    return render(request, 'PatientApp/PatientHomePage.html')