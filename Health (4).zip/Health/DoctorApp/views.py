from django.shortcuts import render

# Create your views here.
def ProjectHomePage(request):
    return render(request,'AdminApp/ProjectHomePage.html')

def DoctorHomePage(request):
    return render(request, 'DoctorApp/DoctorHomePage.html')